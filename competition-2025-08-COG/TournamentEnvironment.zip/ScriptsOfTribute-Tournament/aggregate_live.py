#!/usr/bin/env python3
import argparse, json, os, re, subprocess, sys, time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Tuple, List
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patheffects as path_effects
from matplotlib.ticker import MaxNLocator
import yaml

PAIR_CSV_RE   = re.compile(r"(.+)_vs_(.+)\.csv$")
PAIR_SUMMARY_RE = re.compile(r"(.+)_vs_(.+)_summary\.json$")
ROUND_CSV_RE  = re.compile(r"round_(\d+)\.csv$")

# ---------- RSYNC ----------

def rsync_host(host_cfg: dict, local_root: Path, only_exts: List[str]) -> None:
    dest = local_root / host_cfg["name"]
    dest.mkdir(parents=True, exist_ok=True)

    includes = []
    for ext in only_exts:
        includes += ["--include", f"*{ext}"]

    ident = host_cfg.get("identity_file")  # np. /mnt/c/Users/Ty/.ssh/id_ed25519
    port  = host_cfg.get('port', 22)

    ssh_parts = [
        "ssh", "-p", str(port),
        "-o", "IdentitiesOnly=yes",
        "-o", "BatchMode=yes",                    # bez promptów
        "-o", "StrictHostKeyChecking=accept-new", # akceptuj nowy host key
        "-o", "UserKnownHostsFile=/root/.ssh/known_hosts",
        "-o", "ServerAliveInterval=60",
        "-o", "ServerAliveCountMax=3",
    ]
    if ident:
        ssh_parts += ["-i", ident]

    cmd = [
        "rsync", "-az",
        "-e", " ".join(ssh_parts),
        "--delete", "--prune-empty-dirs",
        "--include", "*/",
        *includes,
        "--exclude", "*",
        f"{host_cfg['ssh']}:{host_cfg['remote_results_dir'].rstrip('/')}/",
        str(dest),
    ]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError as e:
        sys.stderr.write(f"[WARN] rsync {host_cfg['name']} failed: {e}\n")

# ---------- LOADERS (tolerują „półpliki”) ----------

def read_csv_lenient(path: Path) -> pd.DataFrame:
    try:
        # tolerancyjnie: pomijaj wadliwe linie (np. w trakcie dopisywania)
        return pd.read_csv(path, engine="python", on_bad_lines="skip")
    except Exception:
        return pd.DataFrame()

def load_all_round_leaderboards(roots: List[Path]) -> pd.DataFrame:
    rows = []
    for root in roots:
        rdir = root / "rounds"
        if not rdir.exists():
            continue
        for f in sorted(rdir.glob("round_*.csv")):
            df = read_csv_lenient(f)
            if df.empty: 
                continue
            need = {"round_idx","bot","games","wins","draws","losses"}
            if not need.issubset(df.columns):
                continue
            # host tag do ewentualnej diagnostyki
            df["__host"] = root.name
            rows.append(df)
    if not rows:
        return pd.DataFrame(columns=["round_idx","bot","games","wins","draws","losses","eff_wr","eff_wr_pct","__host"])
    out = pd.concat(rows, ignore_index=True)
    if "eff_wr" not in out.columns:
        out["eff_wr"] = (out["wins"] + 0.5*out["draws"]) / out["games"].replace(0, np.nan)
    if "eff_wr_pct" not in out.columns:
        out["eff_wr_pct"] = 100.0 * out["eff_wr"]
    return out

def load_all_pair_rows(roots: List[Path]) -> pd.DataFrame:
    """
    Zbiera wszystkie *_vs_*.csv (nie summaries json), dodając round_idx/side/seed/wins/draws/games...
    Wiersze są niezależne; sumujemy po nich „so far”.
    """
    rows = []
    for root in roots:
        for f in root.glob("*_vs_*.csv"):
            if f.name.endswith("_summary.json"):
                continue
            if not PAIR_CSV_RE.match(f.name):
                continue
            df = read_csv_lenient(f)
            if df.empty:
                continue
            need = {"pair_id","round_idx","side","runs","seed","left","right",
                    "p1_wins","p2_wins","draws","mapped_a_wins","mapped_b_wins","games"}
            if not need.issubset(df.columns):
                # starsza wersja? dalej możemy coś policzyć
                df = df.reindex(columns=list(need & set(df.columns)))
            df["__host"] = root.name
            rows.append(df)
    if not rows:
        return pd.DataFrame()
    return pd.concat(rows, ignore_index=True)

def load_pair_summaries(roots: List[Path]) -> List[Dict]:
    out = []
    for root in roots:
        for p in root.glob("*_summary.json"):
            if not PAIR_SUMMARY_RE.match(p.name):
                continue
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
                d["__host"] = root.name
                out.append(d)
            except Exception:
                pass
    return out

def interleave_round_indices(pair_df: pd.DataFrame, remote_hosts: List[dict]) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Z round_idx oraz __host tworzy round_idx_interleaved:
      new = round_idx * H + host_order + 1
    Dla 2 hostów:
      hostA (order=0): r*2 + 1 -> 1,3,5,...
      hostB (order=1): r*2 + 2 -> 2,4,6,...
    Zwraca: (zaktualizowany DF, mapping do diagnostyki).
    """
    if pair_df.empty or "round_idx" not in pair_df.columns or "__host" not in pair_df.columns:
        return pair_df, pd.DataFrame()

    host_names = [h["name"] for h in remote_hosts]
    host_order = {name: i for i, name in enumerate(host_names)}
    H = max(1, len(host_order))

    df = pair_df.copy()
    df["round_idx"] = df["round_idx"].astype(int)
    df["__host_ord"] = df["__host"].map(host_order).fillna(0).astype(int)
    df["round_idx_interleaved"] = df["round_idx"] * H + df["__host_ord"] + 1  # <-- 1-based

    mapping = (
        df[["round_idx", "__host", "round_idx_interleaved"]]
        .drop_duplicates()
        .sort_values("round_idx_interleaved")
        .reset_index(drop=True)
    )
    return df, mapping

# ---------- AGGREGACJA „SO FAR” ----------

def compute_bot_totals_from_pairs(pair_df: pd.DataFrame) -> pd.DataFrame:
    """
    Liczymy sumy po botach na podstawie dostępnych wierszy par (A vs B),
    korzystając z kolumn mapped_a_wins/mapped_b_wins/draws/games.
    """
    if pair_df.empty:
        return pd.DataFrame(columns=["bot","games","wins","draws","losses","eff_wr","eff_wr_pct"])

    # Rozwiniemy wiersze na dwa rekordy (dla A i B) w przestrzeni botów
    recs = []
    for _, r in pair_df.iterrows():
        # z pair_id: "A_vs_B"
        pid = r.get("pair_id","")
        if "_vs_" in pid:
            aid, bid = pid.split("_vs_", 1)
        else:
            aid, bid = r.get("left","A"), r.get("right","B")

        a_w = int(r.get("mapped_a_wins", 0))
        b_w = int(r.get("mapped_b_wins", 0))
        d   = int(r.get("draws", 0))
        n   = int(r.get("games", 0))

        recs.append(dict(bot=aid, wins=a_w, draws=d, games=n))
        recs.append(dict(bot=bid, wins=b_w, draws=d, games=n))

    df = pd.DataFrame(recs)
    g = df.groupby("bot", as_index=False).agg(wins=("wins","sum"),
                                              draws=("draws","sum"),
                                              games=("games","sum"))
    g["losses"] = g["games"] - g["wins"] - g["draws"]
    g["eff_wr"] = (g["wins"] + 0.5*g["draws"]) / g["games"].replace(0, np.nan)
    g["eff_wr_pct"] = 100.0 * g["eff_wr"]
    g = g.sort_values(["eff_wr","games"], ascending=[False, False]).reset_index(drop=True)
    return g

def compute_h2h_from_pairs(pair_df: pd.DataFrame) -> Tuple[List[str], Dict[Tuple[str,str], Dict]]:
    if pair_df.empty:
        return [], {}
    names = sorted(set(sum([r.split("_vs_") for r in pair_df["pair_id"].unique()], [])))
    h2h: Dict[Tuple[str,str], Dict] = {}
    # sumujemy po (pair_id)
    for pid, grp in pair_df.groupby("pair_id"):
        if "_vs_" not in pid: 
            continue
        A, B = pid.split("_vs_", 1)
        a_w = int(grp["mapped_a_wins"].sum())
        b_w = int(grp["mapped_b_wins"].sum())
        d   = int(grp["draws"].sum())
        n   = int(grp["games"].sum())
        if n <= 0:
            continue
        h2h[(A,B)] = dict(A=A, B=B, a_wins=a_w, b_wins=b_w, draws=d, games=n,
                          A_effWR=(a_w + 0.5*d)/n)
        # lustrzane:
        h2h[(B,A)] = dict(A=B, B=A, a_wins=b_w, b_wins=a_w, draws=d, games=n,
                          A_effWR=(b_w + 0.5*d)/n)
    return names, h2h

# ---------- PLOTTY ----------

def plot_h2h_matrix(out_dir: Path, names: List[str], h2h: Dict[Tuple[str,str], Dict]):
    if not names:
        return
    M = np.full((len(names), len(names)), np.nan)
    for i, a in enumerate(names):
        for j, b in enumerate(names):
            if i == j: 
                continue
            wr = h2h.get((a,b), {}).get("A_effWR", np.nan)
            M[i, j] = 100.0 * wr if not np.isnan(wr) else np.nan

    out_dir.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(0.7*len(names)+2, 0.7*len(names)+2))
    im = plt.imshow(M, vmin=0, vmax=100, interpolation="nearest", aspect="equal", cmap="RdYlGn")
    cbar = plt.colorbar(im, fraction=0.046, pad=0.04)
    cbar.set_label("Eff. WR (%) — row vs col")
    plt.xticks(range(len(names)), names, rotation=90)
    plt.yticks(range(len(names)), names)
    plt.title("Head-to-Head Win Rate (%)")

    for i in range(len(names)):
        for j in range(len(names)):
            if i == j:
                continue
            val = M[i, j]
            if not np.isnan(val):
                txt = plt.text(j, i, f"{val:.1f}%", ha="center", va="center", fontsize=8, color="white")
                txt.set_path_effects([
                    path_effects.Stroke(linewidth=1.2, foreground='black'),
                    path_effects.Normal()
                ])

    plt.tight_layout()
    (out_dir / "h2h_matrix_live.png").parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_dir / "h2h_matrix_live.png", dpi=160)
    plt.close()

def plot_wr_per_round_from_pairs(out_dir: Path, pair_df: pd.DataFrame, round_col: str = "round_idx"):
    """
    Liczymy „cumulative WR per round” z pair_df, używając round_col (domyślnie 'round_idx').
    """
    if pair_df.empty or round_col not in pair_df.columns:
        return
    # rozwinięcie na boty
    recs = []
    for _, r in pair_df.iterrows():
        pid = r.get("pair_id","")
        if "_vs_" in pid:
            aid, bid = pid.split("_vs_", 1)
        else:
            aid, bid = r.get("left","A"), r.get("right","B")
        a_w = int(r.get("mapped_a_wins", 0))
        b_w = int(r.get("mapped_b_wins", 0))
        d   = int(r.get("draws", 0))
        n   = int(r.get("games", 0))
        rnd = int(r.get(round_col, -1))
        recs.append(dict(round_idx=rnd, bot=aid, wins=a_w, draws=d, games=n))
        recs.append(dict(round_idx=rnd, bot=bid, wins=b_w, draws=d, games=n))
    df = pd.DataFrame(recs)
    if df.empty:
        return
    df = df.groupby(["round_idx","bot"], as_index=False).agg(
        wins=("wins","sum"),
        draws=("draws","sum"),
        games=("games","sum"),
    ).sort_values(["bot","round_idx"])
    df["cum_wins"]  = df.groupby("bot")["wins"].cumsum()
    df["cum_draws"] = df.groupby("bot")["draws"].cumsum()
    df["cum_games"] = df.groupby("bot")["games"].cumsum()
    df["cum_eff_wr_pct"] = 100.0 * (df["cum_wins"] + 0.5*df["cum_draws"]) / df["cum_games"].replace(0, np.nan)

    piv = df.pivot_table(index="round_idx", columns="bot", values="cum_eff_wr_pct", aggfunc="last").sort_index()
    if piv.empty:
        return
    last = piv.tail(1).T.squeeze()
    piv = piv.loc[:, last.sort_values(ascending=False).index]
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "wr_per_round_cumulative_live.csv").write_text(piv.to_csv(index=True), encoding="utf-8")

    plt.figure(figsize=(max(10, 1.2*len(piv.columns)), 6))
    for bot in piv.columns:
        plt.plot(
            piv.index.astype(int),
            piv[bot],
            label=bot,
            linewidth=2.0,
            alpha=0.9
        )
    plt.xlabel("round_idx")
    plt.ylabel("Cumulative effective WR (%)")
    plt.title("Cumulative WR (%) by bot across rounds")
    plt.ylim(0, 100)
    ax = plt.gca()
    ax.xaxis.set_major_locator(MaxNLocator(nbins=10, integer=True))
    plt.grid(True, alpha=0.3)
    ncol = 1 if len(piv.columns) <= 10 else 2
    plt.legend(loc="center left", bbox_to_anchor=(1.0, 0.5), ncol=ncol, frameon=False)
    plt.tight_layout()
    plt.savefig(out_dir / "wr_per_round_live.png", dpi=160, bbox_inches="tight")
    plt.close()

def plot_overall_timeseries(output_dir: Path, max_bots: int | None = None):
    out_long  = output_dir / "overall_timeseries_long.csv"
    out_wide  = output_dir / "overall_timeseries_wide.csv"
    plots_dir = output_dir / "plots"
    plots_dir.mkdir(parents=True, exist_ok=True)

    wide = read_csv_safe(out_wide)
    if wide.empty:
        return
    # timestamp jako oś X (stringi też ok dla matplotlib, ale można parsować do daty)
    ts = wide["timestamp"] if "timestamp" in wide.columns else None
    wide = wide.set_index("timestamp")

    # wybierz top-n według ostatniego punktu WR (żeby wykres nie był 100-liniowy)
    last = wide.tail(1).T.squeeze()
    order = last.sort_values(ascending=False).index.tolist()
    if max_bots is not None:
        order = order[:max_bots]
    plt.figure(figsize=(max(10, 0.9*len(order)+8), 6))
    for bot in order:
        if bot in wide.columns:
            plt.plot(wide.index, wide[bot], marker="o", label=bot)
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("Eff. WR (%)")
    plt.ylim(0, 100)
    plt.grid(True, alpha=0.3)
    ncol = 1 if len(order) <= 10 else 2
    plt.legend(loc="center left", bbox_to_anchor=(1.0, 0.5), ncol=ncol, frameon=False)
    plt.title("Effective WR over time")
    plt.tight_layout()
    plt.savefig(plots_dir / "overall_wr_over_time.png", dpi=160, bbox_inches="tight")
    plt.close()

# ---------- PIPELINE ----------
def _now_iso() -> str:
    # ISO bez mikrosekund, w lokalnym czasie (możesz zmienić na UTC)
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def read_csv_safe(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()

def update_overall_snapshot_and_timeseries(output_dir: Path, overall_df: pd.DataFrame):
    """
    - Nadpisuje snapshot: overall_ranking_live.csv
    - Aktualizuje historię: overall_timeseries_long.csv (append)
    - Nadpisuje pivota: overall_timeseries_wide.csv (pivot eff_wr_pct)
    """
    out_snapshot = output_dir / "overall_ranking_live.csv"
    out_long     = output_dir / "overall_timeseries_long.csv"
    out_wide     = output_dir / "overall_timeseries_wide.csv"
    out_wide_g   = output_dir / "overall_timeseries_wide_games.csv"

    output_dir.mkdir(parents=True, exist_ok=True)

    if overall_df.empty:
        # nic nie zapisujemy
        return

    # 1) snapshot (z timestampem w kolumnie pomocniczej)
    snap = overall_df.copy()
    ts = _now_iso()
    snap.insert(0, "timestamp", ts)
    snap.to_csv(out_snapshot, index=False)

    # 2) long history – dopisujemy wiersze tylko gdy jest progres (suma gier wzrosła)
    hist = read_csv_safe(out_long)
    # policz sygnaturę „progresu” = łączna suma gier przez wszystkie boty
    current_total_games = int(snap["games"].sum())
    last_total_games = None
    if not hist.empty and "total_games_all" in hist.columns:
        # bierzemy ostatnią wartość total_games_all
        last_total_games = int(hist["total_games_all"].iloc[-1])

    if (last_total_games is None) or (current_total_games > last_total_games):
        # budujemy long-format: po jednym rekordzie na bota
        long_rows = []
        for _, r in snap.iterrows():
            long_rows.append({
                "timestamp": ts,
                "bot": r["bot"],
                "games": int(r["games"]),
                "wins": int(r["wins"]),
                "draws": int(r["draws"]),
                "losses": int(r["losses"]),
                "eff_wr": float(r["eff_wr"]),
                "eff_wr_pct": float(r["eff_wr_pct"]),
                "total_games_all": current_total_games,
            })
        long_df_new = pd.DataFrame(long_rows)

        if hist.empty:
            long_df_all = long_df_new
        else:
            long_df_all = pd.concat([hist, long_df_new], ignore_index=True)

        long_df_all.to_csv(out_long, index=False)

        # 3) wide pivots (nadpisujemy)
        piv = long_df_all.pivot_table(index="timestamp", columns="bot", values="eff_wr_pct", aggfunc="last")
        piv = piv.sort_index()
        piv.to_csv(out_wide)

        pivg = long_df_all.pivot_table(index="timestamp", columns="bot", values="games", aggfunc="last").sort_index()
        pivg.to_csv(out_wide_g)
    # else: brak zmian -> nie dopisujemy nic do historii, snapshot i tak zaktualizowany

def run_once(cfg: dict):
    local_root   = Path(cfg["local_aggregate_dir"]).resolve()
    output_dir   = Path(cfg["output_dir"]).resolve()
    only_exts    = cfg.get("only_extensions", [".csv",".json"])
    remote_hosts = cfg["remote_hosts"]

    local_root.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1) fetch
    for host in remote_hosts:
        rsync_host(host, local_root, only_exts)

    # 2) merge/aggregate
    host_roots = [local_root / h["name"] for h in remote_hosts]
    rounds_df_all = load_all_round_leaderboards(host_roots)
    pair_df_all   = load_all_pair_rows(host_roots)

    bot_name_map = {
        "Nangert_submission_v4": "NangertAI",
    }

    if not pair_df_all.empty:
        # pair_id jest w formacie "A_vs_B", więc trzeba zamienić oba fragmenty
        def map_pair_id(pid: str) -> str:
            if "_vs_" in pid:
                left, right = pid.split("_vs_", 1)
                return f"{bot_name_map.get(left, left)}_vs_{bot_name_map.get(right, right)}"
            return pid

        if "pair_id" in pair_df_all.columns:
            pair_df_all["pair_id"] = pair_df_all["pair_id"].map(map_pair_id)

        if "left" in pair_df_all.columns:
            pair_df_all["left"] = pair_df_all["left"].map(lambda x: bot_name_map.get(x, x))
        if "right" in pair_df_all.columns:
            pair_df_all["right"] = pair_df_all["right"].map(lambda x: bot_name_map.get(x, x))

        if "__host" in pair_df_all.columns:
            pass  # hostów nie zmieniamy

    pair_df_all, mapping = interleave_round_indices(pair_df_all, remote_hosts)
    if not mapping.empty:
        mapping.to_csv(output_dir / "round_index_mapping.csv", index=False)

    # „overall so far” preferencyjnie z pair_df (bo round_*.csv może nie istnieć jeszcze)
    overall_df = compute_bot_totals_from_pairs(pair_df_all)
    update_overall_snapshot_and_timeseries(output_dir, overall_df)
    plot_overall_timeseries(output_dir, max_bots=20)
    # H2H z par (live)
    names, h2h = compute_h2h_from_pairs(pair_df_all)
    if names:
        # CSV
        M_rows = []
        for a in names:
            row = {"bot": a}
            for b in names:
                row[b] = (0.5 if a == b else h2h.get((a,b), {}).get("A_effWR", np.nan))
            M_rows.append(row)
        h2h_df = pd.DataFrame(M_rows).set_index("bot")
        h2h_df.to_csv(output_dir / "head_to_head_live.csv")
        plot_h2h_matrix(output_dir / "plots", names, h2h)

    plot_wr_per_round_from_pairs(output_dir / "plots", pair_df_all, round_col="round_idx_interleaved")

    # prosty JSON snapshot (live)
    snapshot = {
        "generated_at": int(time.time()),
        "bots": sorted(set(overall_df["bot"])) if not overall_df.empty else names,
        "ranking_live": overall_df.to_dict(orient="records"),
    }
    (output_dir / "tournament_live.json").write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")

    # krótki stdout
    if not overall_df.empty:
        print("\n=== LIVE Overall (effective WR; so far) ===")
        print(overall_df.to_string(index=False))
    print(f"\nSaved into: {output_dir}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--watch", action="store_true", help="Loop: fetch+merge+plot ever N seconds")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    interval = int(cfg.get("fetch_interval_sec", 30))

    if args.watch:
        while True:
            try:
                run_once(cfg)
            except KeyboardInterrupt:
                break
            except Exception as e:
                sys.stderr.write(f"[ERROR] {e}\n")
            time.sleep(interval)
    else:
        run_once(cfg)

if __name__ == "__main__":
    main()
