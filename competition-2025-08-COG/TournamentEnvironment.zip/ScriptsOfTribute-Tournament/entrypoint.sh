#!/usr/bin/env bash
set -euo pipefail

echo "[entry] Python: $(python --version)"
echo "[entry] Dotnet : $(dotnet --version)"
echo "[entry] Workdir : $(pwd)"

./build_cs_bots.sh

exec python run_tournament.py --config config.yaml