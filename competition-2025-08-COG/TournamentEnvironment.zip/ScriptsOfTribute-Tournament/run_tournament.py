# run_tournament.py
import argparse, csv, hashlib, importlib, itertools, json, os, re, sys, time
from dataclasses import dataclass
from pathlib import Path
from subprocess import run, PIPE, CalledProcessError
from typing import List, Optional, Dict, Any, Tuple

from scripts_of_tribute.game import Game

@dataclass
class Bot:
    id: str
    kind: str                 # "python" | "native"
    cls_path: Optional[str]   # for python, e.g. "py_agents.Bots.RandomBot.RandomBot"
    name: Optional[str]       # python bot_name (and grpc:NAME)
    native_name: Optional[str]# for native C# DLL bot

def load_config(path: str) -> dict:
    import yaml
    return yaml.safe_load(Path(path).read_text(encoding="utf-8"))

def seed_for(*parts: str) -> int:
    s = "|".join(parts)
    h = hashlib.blake2b(s.encode(), digest_size=8).digest()
    return int.from_bytes(h, "big", signed=False)

def name_for(entry: Bot) -> str:
    if entry.kind == "python":
        return f"grpc:{entry.name}"
    if entry.kind == "native":
        return entry.native_name
    raise ValueError("unknown kind")

STDOUT_RE = {
    "total_ms": re.compile(r"Total time taken:\s*([0-9]+(?:\.[0-9]+)?)ms"),
    "avg_ms": re.compile(r"Average time per game:\s*([0-9]+(?:\.[0-9]+)?)ms"),
    "draws":    re.compile(r"Final amount of draws:\s*([0-9]+)/([0-9]+)"),
    "p1":       re.compile(r"Final amount of P1 wins:\s*([0-9]+)/([0-9]+)"),
    "p2":       re.compile(r"Final amount of P2 wins:\s*([0-9]+)/([0-9]+)"),
}

def parse_stdout(stdout: str) -> Dict[str, Any]:
    def pick(key):
        m = STDOUT_RE[key].search(stdout)
        return (int(m.group(1)), int(m.group(2))) if m else (0,0)
    total_ms = int(STDOUT_RE["total_ms"].search(stdout).group(1)) if STDOUT_RE["total_ms"].search(stdout) else None
    avg_ms   = float(STDOUT_RE["avg_ms"].search(stdout).group(1))  if STDOUT_RE["avg_ms"].search(stdout) else None
    d, n = pick("draws")
    p1, _ = pick("p1")
    p2, _ = pick("p2")
    return {
        "games": n, "draws": d, "p1_wins": p1, "p2_wins": p2,
        "total_ms": total_ms, "avg_ms": avg_ms
    }

def run_gamerunner_capture(exe_path: Path, left: str, right: str,
                            runs: int, threads: int,
                            log_level: str, log_destination: str,
                            seed: int | None, timeout: int) -> tuple[str, str]:
    exe_path = exe_path.resolve()
    args = [str(exe_path), left, right, "-n", str(runs), "-t", str(threads), "-l", log_level, "-to", str(timeout)]
    if log_destination:
        args += ["-d", log_destination]
    if seed is not None:
        args += ["-s", str(seed)]

    r = run(args, check=True, stdout=PIPE, stderr=PIPE, text=True, cwd=str(exe_path.parent))
    return r.stdout, r.stderr

def ensure_runner_has_bots_dir(runner_path: Path):
    bots_dir = runner_path.parent / "Bots"
    bots_dir.mkdir(parents=True, exist_ok=True)
    return bots_dir

# ---------- CSV helpers ----------

def ensure_csv_with_header(path: Path, fieldnames: List[str]):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        with path.open("w", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=fieldnames).writeheader()

def append_csv_row(path: Path, fieldnames: List[str], row: Dict[str, Any]):
    with path.open("a", newline="", encoding="utf-8") as f:
        cw = csv.DictWriter(f, fieldnames=fieldnames)
        cw.writerow(row)
        f.flush()


# ---------- One match (one direction) ----------

def play_one_side(
    A: Bot, B: Bot, *,  # A left, B right
    runs: int,
    threads: int,
    timeout: int,
    log_level: str,
    log_destination: str,
    runner_path: Path,
    round_idx: int,
    results_dir: Path,
) -> Dict[str, Any]:
    pair_id = f"{A.id}_vs_{B.id}"
    logs_dir = results_dir / "logs" / pair_id
    logs_dir.mkdir(parents=True, exist_ok=True)
    pair_log    = logs_dir / f"{pair_id}.txt"
    pair_errlog = logs_dir / f"{pair_id}.err.txt"

    game = Game()
    def load_py_bot(cls_path: str, name: str):
        mod_name, cls_name = cls_path.rsplit(".", 1)
        mod = importlib.import_module(mod_name)
        cls = getattr(mod, cls_name)
        return cls(bot_name=name)
    a_py = load_py_bot(A.cls_path, A.name) if A.kind == "python" else None
    b_py = load_py_bot(B.cls_path, B.name) if B.kind == "python" else None
    if a_py: game.register_bot(a_py)
    if b_py: game.register_bot(b_py)

    if a_py or b_py:
        base_client_port = 50000
        base_server_port = 49000
        game._run_bot_instances(
            a_py, b_py,
            num_threads=threads,
            base_client_port=base_client_port,
            base_server_port=base_server_port,
        )
        time.sleep(2)

    # run
    seed = seed_for("round", str(round_idx), A.id, B.id)
    stdout, stderr = run_gamerunner_capture(
        exe_path=runner_path,
        left=name_for(A), right=name_for(B),
        runs=runs, threads=threads,
        log_level=log_level, log_destination=log_destination,
        seed=seed, timeout=timeout
    )

    with pair_log.open("a", encoding="utf-8") as flog:
        flog.write(f"\n===== {pair_id} | round {round_idx} | LEFT={A.id} RIGHT={B.id} | runs={runs} | seed={seed} =====\n")
        flog.write(stdout)
    if stderr:
        with pair_errlog.open("a", encoding="utf-8") as ferr:
            ferr.write(f"\n===== {pair_id} | round {round_idx} | LEFT={A.id} RIGHT={B.id} | runs={runs} | seed={seed} =====\n")
            ferr.write(stderr)

    if a_py or b_py:
        game._cleanup_processes()

    parsed = parse_stdout(stdout)
    return {"seed": seed, **parsed}

def play_pair_one_round(
    A: Bot, B: Bot,
    *, runs_per_round: int, threads: int, timeout: int,
    log_level: str, log_destination: str,
    runner_path: Path, round_idx: int,
    pair_csv: Path
) -> Dict[str, Any]:
    # balance sides inside the round: split K into ceil/floor
    left_runs = runs_per_round // 2
    right_runs = runs_per_round - left_runs

    fields = ["pair_id","round_idx","side","runs","seed","left","right",
              "p1_wins","p2_wins","draws","mapped_a_wins","mapped_b_wins","games","avg_ms"]
    ensure_csv_with_header(pair_csv, fields)

    stats = {"a_wins": 0, "b_wins": 0, "draws": 0, "games": 0}

    if left_runs > 0:
        res = play_one_side(
            A, B, runs=left_runs, threads=threads, timeout=timeout,
            log_level=log_level, log_destination=log_destination,
            runner_path=runner_path, round_idx=round_idx, results_dir=pair_csv.parent
        )
        a_w, b_w = res["p1_wins"], res["p2_wins"]
        stats["a_wins"] += a_w; stats["b_wins"] += b_w
        stats["draws"]  += res["draws"]; stats["games"] += res["games"]
        append_csv_row(pair_csv, fields, {
            "pair_id": f"{A.id}_vs_{B.id}",
            "round_idx": round_idx, "side": "LEFT_A",
            "runs": left_runs, "seed": res["seed"],
            "left": name_for(A), "right": name_for(B),
            "p1_wins": res["p1_wins"], "p2_wins": res["p2_wins"], "draws": res["draws"],
            "mapped_a_wins": a_w, "mapped_b_wins": b_w,
            "games": res["games"], "avg_ms": res.get("avg_ms"),
        })

    if right_runs > 0:
        res = play_one_side(
            B, A, runs=right_runs, threads=threads, timeout=timeout,
            log_level=log_level, log_destination=log_destination,
            runner_path=runner_path, round_idx=round_idx, results_dir=pair_csv.parent
        )
        a_w, b_w = res["p2_wins"], res["p1_wins"]  # map back to (A,B)
        stats["a_wins"] += a_w; stats["b_wins"] += b_w
        stats["draws"]  += res["draws"]; stats["games"] += res["games"]
        append_csv_row(pair_csv, fields, {
            "pair_id": f"{A.id}_vs_{B.id}",
            "round_idx": round_idx, "side": "LEFT_B",
            "runs": right_runs, "seed": res["seed"],
            "left": name_for(B), "right": name_for(A),
            "p1_wins": res["p1_wins"], "p2_wins": res["p2_wins"], "draws": res["draws"],
            "mapped_a_wins": a_w, "mapped_b_wins": b_w,
            "games": res["games"], "avg_ms": res.get("avg_ms"),
        })

    return stats

# ---------- Main tournament with rounds ----------

def run_tournament_with_rounds(bots: List[Bot], cfg: dict, runner_path: Path, results_dir: Path):
    rounds = int(cfg.get("rounds", 1))
    threads = int(cfg.get("threads_per_match", 1))
    runs_per_round = int(cfg.get("games_per_pair_per_round", cfg.get("chunk_size", 1)))
    timeout = int(cfg["timeout"])
    log_level = cfg.get("log_level", "NONE")
    log_destination = cfg.get("log_destination", "")

    pairs = list(itertools.combinations(bots, 2))
    rounds_dir = results_dir / "rounds"
    rounds_dir.mkdir(parents=True, exist_ok=True)
    leaderboard_fields = ["round_idx","bot","games","wins","draws","losses","eff_wr","eff_wr_pct"]

    cum_pair_stats: Dict[Tuple[str,str], Dict[str,int]] = {}

    for r in range(rounds):
        print(f"\n=== Round {r} ===")
        per_bot = {b.id: {"games":0,"wins":0,"draws":0,"losses":0} for b in bots}

        for A, B in pairs:
            pair_id = f"{A.id}_vs_{B.id}"
            pair_csv = results_dir / f"{pair_id}.csv"
            stats = play_pair_one_round(
                A, B,
                runs_per_round=runs_per_round,
                threads=threads, timeout=timeout,
                log_level=log_level, log_destination=log_destination,
                runner_path=runner_path, round_idx=r,
                pair_csv=pair_csv
            )

            per_bot[A.id]["wins"]  += stats["a_wins"]
            per_bot[A.id]["draws"] += stats["draws"]
            per_bot[A.id]["games"] += stats["games"]
            per_bot[A.id]["losses"] = per_bot[A.id]["games"] - per_bot[A.id]["wins"] - per_bot[A.id]["draws"]

            per_bot[B.id]["wins"]  += stats["b_wins"]
            per_bot[B.id]["draws"] += stats["draws"]
            per_bot[B.id]["games"] += stats["games"]
            per_bot[B.id]["losses"] = per_bot[B.id]["games"] - per_bot[B.id]["wins"] - per_bot[B.id]["draws"]

            k = (A.id, B.id)
            if k not in cum_pair_stats:
                cum_pair_stats[k] = {"a_wins":0,"b_wins":0,"draws":0,"games":0}
            for key in ["a_wins","b_wins","draws","games"]:
                cum_pair_stats[k][key] += stats[key]

            print(f"  {A.id} vs {B.id}: +{stats['a_wins']}-{stats['b_wins']}-{stats['draws']} / {stats['games']}")

        lb_path = rounds_dir / f"round_{r}.csv"
        ensure_csv_with_header(lb_path, leaderboard_fields)
        for bot_id, s in per_bot.items():
            games = s["games"]
            eff = (s["wins"] + 0.5*s["draws"]) / games if games else 0.0
            append_csv_row(lb_path, leaderboard_fields, {
                "round_idx": r, "bot": bot_id,
                "games": games, "wins": s["wins"], "draws": s["draws"], "losses": s["losses"],
                "eff_wr": eff, "eff_wr_pct": 100.0*eff
            })

    for (aid, bid), st in cum_pair_stats.items():
        summary = {
            "pair_id": f"{aid}_vs_{bid}",
            "A": aid, "B": bid,
            **st,
            "A_effWR": (st["a_wins"] + 0.5*st["draws"]) / st["games"] if st["games"] else 0.0,
            "timestamp": int(time.time())
        }
        (results_dir / f"{aid}_vs_{bid}_summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--only-pairs", nargs="*", default=None, help="Optional: list of pairs in format A:B")
    args = ap.parse_args()

    cfg = load_config(args.config)
    results_dir = Path("results"); results_dir.mkdir(exist_ok=True)

    runner_path = None
    if cfg.get("use_local_runner", True):
        runner_path = Path(cfg["runner_path"])
        ensure_runner_has_bots_dir(runner_path)

    bots = [Bot(
        id=b["id"],
        kind=b["kind"],
        cls_path=b.get("class"),
        name=b.get("name"),
        native_name=b.get("native_name"),
    ) for b in cfg["bots"]]
    by_id = {b.id: b for b in bots}

    pairs_ids = list(itertools.combinations([b.id for b in bots], 2))
    if args.only_pairs:
        wanted = {tuple(p.split(":")) for p in args.only_pairs}
        pairs_ids = [p for p in pairs_ids if p in wanted or (p[1], p[0]) in wanted]
    used_ids = sorted({x for p in pairs_ids for x in p})
    bots = [by_id[i] for i in used_ids]

    run_tournament_with_rounds(bots, cfg, Path(cfg["runner_path"]), results_dir)

if __name__ == "__main__":
    main()
    print("~~~~~~~Done~~~~~~~")
