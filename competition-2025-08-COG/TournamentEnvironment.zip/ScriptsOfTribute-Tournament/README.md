Usage Instructions

1. Adding C# bots
   - Place the bot's folder inside cs_agents/
   - If the bot has its own .csproj file, it will be used.
   - If there is no .csproj file, all .cs files will be automatically compiled into a DLL.

2. Adding Python bots
   - Place the bot's folder inside py_agents/
   - If the bot has dependencies, add a requirements.txt file inside the folder.
   - The bot class must implement the required Scripts of Tribute interface.

3. Running the tournament
   - Configure config.yaml (bot list, number of games, threads, etc.).
   - Run:
     `docker compose up --build`

4. Accessing logs
   - Game logs are stored in results/.
   - CSV result files are in results/.

5. Generating a summary
   - After the tournament ends, generate the summary with:
     `docker compose run --rm tour bash -lc "pip install --no-cache-dir -r requirements.txt && python summarize_tournament.py"`
   - You can run it during the tournament as well to get wr per round plot formed of the round already finished, it will be in results/plots.
   - The summary file will be stored in results/.
