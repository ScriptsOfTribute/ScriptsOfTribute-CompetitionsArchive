#!/usr/bin/env bash
set -euo pipefail

mkdir -p /root/.ssh
# klucz i known_hosts przychodzą z mountu /keys
if [[ -f /keys/id_ed25519 ]]; then
  cp /keys/id_ed25519 /root/.ssh/id_ed25519
  chmod 600 /root/.ssh/id_ed25519
fi
if [[ -f /keys/known_hosts ]]; then
  cp /keys/known_hosts /root/.ssh/known_hosts
  chmod 644 /root/.ssh/known_hosts
fi

# (opcjonalnie, jeśli nie masz known_hosts)
# ssh-keyscan -p 22 157.230.31.3 >> /root/.ssh/known_hosts || true
# ssh-keyscan -p 22 164.92.177.189 >> /root/.ssh/known_hosts || true
# chmod 644 /root/.ssh/known_hosts

# --- ssh-agent + askpass dla klucza z hasłem ---
eval "$(ssh-agent -s)"

# prosty skrypt askpass, który zwraca frazę z ENV
cat >/app/askpass.sh <<'EOF'
#!/usr/bin/env bash
exec printf "%s" "${SSH_KEY_PASSPHRASE:-}"
EOF
chmod +x /app/askpass.sh

export SSH_ASKPASS=/app/askpass.sh
export SSH_ASKPASS_REQUIRE=force
export DISPLAY=:0

# załaduj klucz do agenta (nie pyta w TTY, użyje ASKPASS)
ssh-add /root/.ssh/id_ed25519 </dev/null

# opcjonalnie: sprawdź, że agent ma klucz
ssh-add -l

exec python /app/aggregate_live.py --config /app/live_agg.yaml --watch
