#!/usr/bin/env bash
set -euo pipefail

BOTS_DIR="/app/runner/Bots"
SRC_ROOT="/app/cs_agents"
RUNNER_DIR="/app/runner"
STAGE_ROOT="/tmp/build"

mkdir -p "$BOTS_DIR" "$STAGE_ROOT"

if [ ! -d "$SRC_ROOT" ]; then
  echo "[build-cs] $SRC_ROOT not found — skipping C# build"
  exit 0
fi

if [ -f "$RUNNER_DIR/TalesOfTribute.dll" ]; then
  REF_DLL="$RUNNER_DIR/TalesOfTribute.dll"
else
  echo "[build-cs] ERROR: $RUNNER_DIR/TalesOfTribute.dll not found" >&2
  exit 1
fi

# --- helpers ---

patch_csproj_in_place() {
  local proj="$1"
  awk '
    BEGIN{skip=0}
    /<ProjectReference[[:space:]>]/{
      if ($0 ~ /\/>/) { next }
      skip=1; next
    }
    skip==1 { if ($0 ~ /<\/ProjectReference>/) { skip=0 } ; next }
    { print }
  ' "$proj" > "$proj.__tmp__" && mv "$proj.__tmp__" "$proj"

  if ! grep -q 'Reference Include="TalesOfTribute"' "$proj"; then
    awk -v dll="$REF_DLL" '
      BEGIN{done=0}
      /<\/Project>/ && done==0 {
        print "  <ItemGroup>";
        print "    <Reference Include=\"TalesOfTribute\"><HintPath>" dll "</HintPath></Reference>";
        print "  </ItemGroup>";
        done=1;
      }
      { print }
    ' "$proj" > "$proj.__tmp__" && mv "$proj.__tmp__" "$proj"
  fi
}

generate_auto_csproj() {
  local bot="$1"
  local wdir="$STAGE_ROOT/$bot"
  mkdir -p "$wdir"
  local proj="$wdir/__auto__.csproj"
  cat > "$proj" <<EOF
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <AssemblyName>${bot}</AssemblyName>
    <LangVersion>10</LangVersion>
  </PropertyGroup>

  <ItemGroup>
    <Compile Include="${SRC_ROOT}/${bot}/**/*.cs" />
  </ItemGroup>

  <ItemGroup>
    <Reference Include="TalesOfTribute">
      <HintPath>${REF_DLL}</HintPath>
    </Reference>
  </ItemGroup>

  <!-- skopiuj wszystkie nie-kodowe assets -->
  <ItemGroup>
    <None Include="${SRC_ROOT}/${bot}/**/*"
          Exclude="${SRC_ROOT}/${bot}/**/*.cs;${SRC_ROOT}/${bot}/**/*.csproj"
          CopyToOutputDirectory="PreserveNewest" />
  </ItemGroup>
</Project>
EOF
  echo "$proj"
}

build_and_stage() {
  # $1 = .csproj ; $2 = staging dir ; $3 = BotName
  local proj="$1"
  local workdir="$2"
  local botname="$3"
  local outdir="$workdir/bin/publish"
  local stage="$workdir/__stage_publish"

  dotnet restore "$proj"
  dotnet publish "$proj" -c Release -f net8.0 -o "$outdir" \
    /p:DebugType=None /p:DebugSymbols=false /p:ContinuousIntegrationBuild=true

  echo "[build-cs]   stage publish → $stage"
  rm -rf "$stage"
  mkdir -p "$stage"

  # 1) copy whole publish
  cp -a "$outdir"/. "$stage"/

  # 2) copy any assets used by bots
  local src_bot_dir="$SRC_ROOT/$botname"
  if [ -d "$src_bot_dir" ]; then
    while IFS= read -r -d '' f; do
      rel="${f#"$src_bot_dir/"}"            # np. Ensemble_Tree_Models/LightGbm
      mkdir -p "$stage/$(dirname "$rel")"
      cp -a "$f" "$stage/$rel"
    done < <(find "$src_bot_dir" -type f ! -name '*.cs' ! -name '*.csproj' -print0)
  fi

  # 3) remove any conflicting duplicates if any (shouldnt happen [I DONT KNOW ANYMORE])
  find "$stage" -type f \
    \( -name 'System.*' \
       -o -name 'Microsoft.AspNetCore.*' \
       -o -name 'Microsoft.Extensions.*' \
       -o -name 'Microsoft.JSInterop.dll' \
       -o -name 'Microsoft.Net.Http.Headers.dll' \
       -o -name 'Google.Protobuf.dll' \
       -o -name 'Grpc.*.dll' \
       -o -name 'Newtonsoft.Json.dll' \
       -o -name 'TalesOfTribute.dll' \
    \) -print -delete || true

  # 4) move all to Bots
  echo "[build-cs]   copy stage → $BOTS_DIR"
  mkdir -p "$BOTS_DIR"
  cp -a "$stage"/. "$BOTS_DIR"/

  # 5) MIRROR assets (without *.dll) to /app/runner/<BotName>/…
  local bot_runtime_dir="$RUNNER_DIR/$botname"
  mkdir -p "$bot_runtime_dir"
  while IFS= read -r -d '' src; do
    rel="${src#"$stage/"}"
    mkdir -p "$bot_runtime_dir/$(dirname "$rel")"
    cp -a "$src" "$bot_runtime_dir/$rel"
  done < <(find "$stage" -type f ! -name '*.dll' -print0)
}

shopt -s nullglob

for BOTDIR in "$SRC_ROOT"/*/ ; do
  [ -d "$BOTDIR" ] || continue
  BOTNAME="$(basename "$BOTDIR")"
  echo "[build-cs] Bot dir: $BOTDIR"

  CSPROJ=( "$BOTDIR"/*.csproj )
  if [ -f "${CSPROJ[0]:-}" ]; then
    STAGED="$STAGE_ROOT/$BOTNAME"
    rm -rf "$STAGED"; mkdir -p "$STAGED"
    echo "[build-cs]   csproj found → staging to $STAGED"
    cp -a "$BOTDIR"/. "$STAGED"/
    PROJ="$STAGED/$(basename "${CSPROJ[0]}")"
    patch_csproj_in_place "$PROJ"
    build_and_stage "$PROJ" "$STAGED" "$BOTNAME"
  else
    if ! find "$BOTDIR" -type f -name "*.cs" -print -quit | grep -q . ; then
      echo "[build-cs]   no .cs files — skip"
      continue
    fi
    echo "[build-cs]   no csproj → generating auto-csproj"
    PROJ="$(generate_auto_csproj "$BOTNAME")"
    WORKDIR="$(dirname "$PROJ")"
    build_and_stage "$PROJ" "$WORKDIR" "$BOTNAME"
  fi
done

echo "[build-cs] done."
