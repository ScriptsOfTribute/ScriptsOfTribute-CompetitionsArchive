#!/usr/bin/env python3
import argparse
from pathlib import Path
from typing import List, Dict, Tuple
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patheffects as path_effects
from matplotlib.ticker import MaxNLocator

# ---------- BOT NAME MAP (final) ----------
BOT_NAME_MAP: Dict[str, str] = {
    # scalanie wariantów nazw do jednej kanonicznej
    "EBot_C": "EBot_C",
    "EBot_F": "EBot_F",
    "BestMCTS3": "BestMCTS3",
    "Nangert_submission_v4": "NAgent",
    "HQL_Plus_BOT": "HQL_Plus_BOT",
    "MaltheMCTS": "MaltheMCTS",
    "Council_of_two_bot": "Council Of Two",
    "ZMyBot": "ZMyBot",            # defensywnie
    "Sakkirina": "Sakkirina",
    "SakkirinaSolo": "SakkirinaSolo",
    "AIFBotMCTS": "MCTS_MMHVR",
}

def map_bot(name: str) -> str:
    return BOT_NAME_MAP.get(str(name), str(name))

# ---------- IO helpers ----------
def read_csv_lenient(p: Path) -> pd.DataFrame:
    try:
        return pd.read_csv(p, on_bad_lines="skip")
    except Exception:
        return pd.DataFrame()

def load_pair_csvs(roots: List[Path]) -> pd.DataFrame:
    """Zbiera wszystkie *_vs_*.csv z katalogów rootów (bez summary.json)."""
    rows = []
    for root in roots:
        for f in root.glob("*_vs_*.csv"):
            if f.name.endswith("_summary.json"):
                continue
            df = read_csv_lenient(f)
            if df.empty: 
                continue
            df["__host"] = root.name
            rows.append(df)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()

def load_round_csvs(roots: List[Path]) -> pd.DataFrame:
    """Zbiera wszystkie rounds/round_*.csv z katalogów rootów."""
    rows = []
    for root in roots:
        rdir = root / "rounds"
        if not rdir.exists():
            continue
        for f in sorted(rdir.glob("round_*.csv")):
            df = read_csv_lenient(f)
            if df.empty:
                continue
            need = {"round_idx","bot","games","wins","draws","losses"}
            if not need.issubset(df.columns):
                continue
            df["__host"] = root.name
            rows.append(df)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def equalize_rounds_to_common_games(rounds_df: pd.DataFrame,
                                    interleave_map: pd.DataFrame) -> pd.DataFrame:
    """
    Equalizacja na bazie plików 'rounds': bierzemy tylko te (host, round_idx),
    w których KAŻDY bot ma pełną i równą liczbę gier (np. 80). Następnie
    bierzemy wspólny prefiks takich pełnych rund na wszystkich hostach i
    liczymy ranking. Efekt: każdy bot ma identyczną liczbę gier.
    """
    cols = ["bot","games","wins","draws","losses","eff_wr","eff_wr_pct"]
    if rounds_df.empty:
        return pd.DataFrame(columns=cols)

    df = rounds_df.copy()
    # 1) oczekiwany zestaw botów = przekrój botów występujących na wszystkich hostach
    bots_per_group = df.groupby(["__host","round_idx"])["bot"].unique().reset_index(name="bots")
    bots_per_host = bots_per_group.groupby("__host")["bots"].apply(lambda x: set().union(*map(set, x))).to_dict()
    if not bots_per_host:
        return pd.DataFrame(columns=cols)
    expected_bots = set.intersection(*[set(v) for v in bots_per_host.values()])  # wspólny komplet botów
    if not expected_bots:
        return pd.DataFrame(columns=cols)

    # 2) znajdź pełne grupy (host, round_idx): komplet botów + jednakowa liczba 'games' w tej grupie
    full_groups = []
    for (h, r), grp in df.groupby(["__host","round_idx"]):
        bots = set(grp["bot"])
        if not expected_bots.issubset(bots):
            continue
        # czy wszystkie 'games' jednakowe i >0 dla expected_bots?
        sub = grp[grp["bot"].isin(expected_bots)]
        if sub.empty:
            continue
        unique_games = sub["games"].unique()
        if (len(unique_games) == 1) and (int(unique_games[0]) > 0):
            full_groups.append((h, int(r), int(unique_games[0])))

    if not full_groups:
        return pd.DataFrame(columns=cols)

    full_df = pd.DataFrame(full_groups, columns=["__host","round_idx","games_per_round"])
    # 3) policz ile pełnych rund ma każdy host i wybierz wspólny prefiks (C)
    keep = full_df[["__host","round_idx"]].drop_duplicates()

    df_eq = df.merge(keep, on=["__host","round_idx"], how="inner")
    # 5) agregacja do rankingu
    g = df_eq.groupby("bot", as_index=False).agg(
        wins=("wins","sum"),
        draws=("draws","sum"),
        games=("games","sum"),
    )
    g["losses"]     = g["games"] - g["wins"] - g["draws"]
    g["eff_wr"]     = (g["wins"] + 0.5*g["draws"]) / g["games"].replace(0, np.nan)
    g["eff_wr_pct"] = 100.0 * g["eff_wr"]
    g = g.sort_values(["eff_wr","games","bot"], ascending=[False, False, True]).reset_index(drop=True)
    # --- DEBUG: zapisz diagnostykę pełnych i odrzuconych rund ---
    diag_rows = []
    # policz zestaw pełnych (host, round) które trafiły do equalizacji
    kept = set(map(tuple, df_eq[["__host","round_idx"]].drop_duplicates().values))
    # zbuduj info dlaczego inne odpadły
    for (h, r), grp in rounds_df.groupby(["__host","round_idx"]):
        bots = set(grp["bot"])
        has_all = expected_bots.issubset(bots)
        sub = grp[grp["bot"].isin(expected_bots)]
        eq_games = (len(sub["games"].unique()) == 1) and (int(sub["games"].unique()[0]) > 0) if has_all else False
        status = "KEPT" if (h, int(r)) in kept else "REJECTED"
        reason = ("OK" if status=="KEPT"
                  else ("MISSING_BOTS" if not has_all else ("UNEQUAL_GAMES" if not eq_games else "OTHER")))
        diag_rows.append(dict(host=h, round_idx=int(r), status=status, reason=reason))
    pd.DataFrame(diag_rows).sort_values(["host","round_idx"]).to_csv(
        Path("equalization_diagnostics.csv"), index=False
    )
    return g

# ---------- Interleaving rund ----------
def build_interleave_mapping(rounds_df: pd.DataFrame, host_order: List[str]) -> pd.DataFrame:
    """
    Z rounds_df (ma round_idx + __host) buduje mapę:
    (round_idx, __host) -> round_idx_interleaved = r*H + host_ord + 1
    """
    if rounds_df.empty: 
        return pd.DataFrame()
    order_map = {h:i for i, h in enumerate(host_order)}
    df = rounds_df[["round_idx","__host"]].drop_duplicates().copy()
    df["round_idx"] = df["round_idx"].astype(int)
    df["__host_ord"] = df["__host"].map(order_map).fillna(0).astype(int)
    H = max(1, len(order_map))
    df["round_idx_interleaved"] = df["round_idx"] * H + df["__host_ord"] + 1
    return df

# ---------- Transformacje / liczenie ----------
def normalize_pairs(pair_df: pd.DataFrame) -> pd.DataFrame:
    """Zastosuj mapowanie nazw do pair_df (pair_id, left, right)."""
    if pair_df.empty:
        return pair_df
    df = pair_df.copy()

    # pair_id -> zamiana obu stron
    if "pair_id" in df.columns:
        def map_pair_id(pid: str) -> str:
            if isinstance(pid, str) and "_vs_" in pid:
                a, b = pid.split("_vs_", 1)
                return f"{map_bot(a)}_vs_{map_bot(b)}"
            return pid
        df["pair_id"] = df["pair_id"].map(map_pair_id)

    if "left" in df.columns:
        df["left"] = df["left"].map(map_bot)
    if "right" in df.columns:
        df["right"] = df["right"].map(map_bot)

    return df

def normalize_rounds(rounds_df: pd.DataFrame) -> pd.DataFrame:
    if rounds_df.empty: 
        return rounds_df
    df = rounds_df.copy()
    df["bot"] = df["bot"].map(map_bot)
    # recompute eff wr just in case of float artifacts
    if "eff_wr" not in df.columns or "eff_wr_pct" not in df.columns:
        df["eff_wr"] = (df["wins"] + 0.5*df["draws"]) / df["games"].replace(0, np.nan)
        df["eff_wr_pct"] = 100.0 * df["eff_wr"]
    return df

def compute_overall_from_pairs(pair_df: pd.DataFrame) -> pd.DataFrame:
    """
    Sumy po botach z wierszy par: mapped_a_wins/mapped_b_wins/draws/games.
    """
    if pair_df.empty:
        return pd.DataFrame(columns=["bot","games","wins","draws","losses","eff_wr","eff_wr_pct"])
    need = {"pair_id","mapped_a_wins","mapped_b_wins","draws","games"}
    missing = need - set(pair_df.columns)
    if missing:
        # nie ma potrzebnych kolumn -> nie policzymy z par
        return pd.DataFrame(columns=["bot","games","wins","draws","losses","eff_wr","eff_wr_pct"])

    recs = []
    for _, r in pair_df.iterrows():
        pid = r.get("pair_id", "")
        if "_vs_" not in pid:
            continue
        a, b = pid.split("_vs_", 1)
        a_w = int(r.get("mapped_a_wins", 0))
        b_w = int(r.get("mapped_b_wins", 0))
        d   = int(r.get("draws", 0))
        n   = int(r.get("games", 0))
        recs.append(dict(bot=a, wins=a_w, draws=d, games=n))
        recs.append(dict(bot=b, wins=b_w, draws=d, games=n))

    df = pd.DataFrame(recs)
    if df.empty:
        return pd.DataFrame(columns=["bot","games","wins","draws","losses","eff_wr","eff_wr_pct"])

    g = df.groupby("bot", as_index=False).agg(wins=("wins","sum"),
                                              draws=("draws","sum"),
                                              games=("games","sum"))
    g["losses"] = g["games"] - g["wins"] - g["draws"]
    g["eff_wr"] = (g["wins"] + 0.5*g["draws"]) / g["games"].replace(0, np.nan)
    g["eff_wr_pct"] = 100.0 * g["eff_wr"]
    g = g.sort_values(["eff_wr","games"], ascending=[False, False]).reset_index(drop=True)
    return g

def compute_h2h_from_pairs(pair_df: pd.DataFrame) -> Tuple[List[str], Dict[Tuple[str,str], float]]:
    if pair_df.empty or "pair_id" not in pair_df.columns:
        return [], {}
    need = {"pair_id","mapped_a_wins","mapped_b_wins","draws","games"}
    if not need.issubset(pair_df.columns):
        return [], {}

    names = sorted(set(sum([pid.split("_vs_") for pid in pair_df["pair_id"].unique() if "_vs_" in pid], [])))
    h2h: Dict[Tuple[str,str], float] = {}
    for pid, grp in pair_df.groupby("pair_id"):
        if "_vs_" not in pid: 
            continue
        A, B = pid.split("_vs_", 1)
        a_w = int(grp["mapped_a_wins"].sum())
        b_w = int(grp["mapped_b_wins"].sum())
        d   = int(grp["draws"].sum())
        n   = int(grp["games"].sum())
        if n <= 0:
            continue
        h2h[(A,B)] = (a_w + 0.5*d) / n
        h2h[(B,A)] = (b_w + 0.5*d) / n
    return names, h2h

# ---------- Plot: H2H ----------
def plot_h2h(out_dir: Path, names: List[str], h2h: Dict[Tuple[str,str], float]):
    if not names:
        return
    M = np.full((len(names), len(names)), np.nan)
    for i, a in enumerate(names):
        for j, b in enumerate(names):
            if i == j: 
                continue
            M[i, j] = 100.0 * h2h.get((a,b), np.nan)

    out_dir.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(0.9*len(names)+2, 0.9*len(names)+2))
    im = plt.imshow(M, vmin=0, vmax=100, interpolation="nearest", aspect="equal", cmap="RdYlGn")
    cbar = plt.colorbar(im, fraction=0.046, pad=0.04)
    cbar.set_label("Eff. WR (%) — row vs col")
    plt.xticks(range(len(names)), names, rotation=90)
    plt.yticks(range(len(names)), names)
    for i in range(len(names)):
        for j in range(len(names)):
            if i == j:
                continue
            val = M[i, j]
            if not np.isnan(val):
                plt.text(
                    j, i, f"{val:.1f}%", 
                    ha="center", va="center", fontsize=14, color="black"
                )
    plt.tight_layout()
    plt.savefig(out_dir / "h2h_matrix.png", dpi=160)
    plt.close()

    pd.DataFrame(M, index=names, columns=names).to_csv(out_dir / "h2h_matrix.csv")

# ---------- Plot: WR per round z plików rund ----------
def plot_wr_per_round_from_rounds(out_dir: Path, rounds_df: pd.DataFrame, interleave_map: pd.DataFrame):
    if rounds_df.empty or interleave_map.empty:
        return
    df = rounds_df.merge(interleave_map, on=["round_idx","__host"], how="inner")
    # akumulacja po rosnącym round_idx_interleaved
    df = df.sort_values(["round_idx_interleaved", "bot"]).copy()
    # kumulacja per bot
    df["cum_wins"]  = df.groupby("bot")["wins"].cumsum()
    df["cum_draws"] = df.groupby("bot")["draws"].cumsum()
    df["cum_games"] = df.groupby("bot")["games"].cumsum()
    df["cum_eff_wr_pct"] = 100.0 * (df["cum_wins"] + 0.5*df["cum_draws"]) / df["cum_games"].replace(0, np.nan)

    piv = df.pivot_table(index="round_idx_interleaved", columns="bot", values="cum_eff_wr_pct", aggfunc="last").sort_index()
    if piv.empty:
        return

    # posortuj legendę wg końcowego WR
    last = piv.tail(1).T.squeeze().sort_values(ascending=False)
    piv = piv.loc[:, last.index]

    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "wr_per_round_cumulative.csv").write_text(piv.to_csv(index=True), encoding="utf-8")

    plt.figure(figsize=(max(10, 1.2*len(piv.columns)), 6))
    for bot in piv.columns:
        plt.plot(piv.index.astype(int), piv[bot], label=bot, linewidth=2.0, alpha=0.9)
    plt.xlabel("Round")
    plt.ylabel("Cumulative effective WR (%)")
    plt.title("Cumulative WR (%)")
    plt.ylim(0, 100)
    ax = plt.gca()
    ax.xaxis.set_major_locator(MaxNLocator(nbins=10, integer=True))
    plt.grid(True, alpha=0.3)
    ncol = 1 if len(piv.columns) <= 12 else 2
    plt.legend(loc="center left", bbox_to_anchor=(1.0, 0.5), ncol=ncol, frameon=False)
    plt.tight_layout()
    plt.savefig(out_dir / "wr_per_round.png", dpi=160, bbox_inches="tight")
    plt.close()

# ---------- Ranking: PNG tabela ----------
def save_ranking_csv_and_png(out_dir: Path, overall_df: pd.DataFrame):
    if overall_df.empty:
        return
    out_dir.mkdir(parents=True, exist_ok=True)
    overall_df.to_csv(out_dir / "ranking.csv", index=False)

    pretty_map = {
        "bot": "Agent",
        "games": "Games",
        "wins": "Wins",
        "draws": "Draws",
        "losses": "Losses",
        "eff_wr_pct": "WR%",
    }
    target_cols = ["Agent", "Games", "Wins", "Draws", "Losses", "WR%"]

    if set(pretty_map.keys()).issubset(overall_df.columns):
        show = overall_df.rename(columns=pretty_map)
    else:
        show = overall_df.copy()
    missing = [c for c in target_cols if c not in show.columns]
    if missing:
        # Spróbuj dorobić brakujące z odpowiedników technicznych (gdyby były mixy)
        rev_map = {v: k for k, v in pretty_map.items()}
        for c in missing:
            src = rev_map.get(c)
            if src in overall_df.columns:
                show[c] = overall_df[src]
        # finalny check
        missing = [c for c in target_cols if c not in show.columns]
        if missing:
            # jeżeli dalej brakuje, po prostu odfiltruj do dostępnych i kontynuuj
            target_cols = [c for c in target_cols if c in show.columns]

    show = show[target_cols].copy()

    # Format WR%
    if "WR%" in show.columns:
        show["WR%"] = show["WR%"].astype(float).map(lambda x: f"{x:.2f}")

    # --- dopasowanie szerokości pod najdłuższą nazwę agenta ---
    first_col = "Agent" if "Agent" in show.columns else show.columns[0]
    max_name_len = int(show[first_col].astype(str).str.len().max() or 8)
    fig_w = max(8.0, 0.18 * max_name_len + 6.5)
    fig_h = max(3.5, 0.5 * len(show) + 1)

    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    ax.axis("off"); ax.axis("tight")

    ncols = len(target_cols)
    # 1. kolumna szersza, reszta dzieli pozostałą szerokość
    first_col_w = min(0.55, 0.25 + 0.001 * max_name_len)
    rest = max(0.45, 1.0 - first_col_w)
    col_widths = [first_col_w] + [rest / (ncols - 1)] * (ncols - 1) if ncols > 1 else [1.0]

    tbl = ax.table(
        cellText=show.values,
        colLabels=show.columns,
        colWidths=col_widths,
        loc="center",
        cellLoc="right",  # liczby po prawej
    )
    tbl.auto_set_font_size(False); tbl.set_fontsize(10); tbl.scale(1.0, 1.15)

    # header: bold + center
    for j in range(ncols):
        c = tbl[0, j]
        c.set_text_props(weight="bold", ha="center")

    # 1. kolumna (Agent) wyrównana do lewej + miękkie łamanie po "_"
    first_col_idx = 0
    for i in range(1, len(show) + 1):
        c = tbl[i, first_col_idx]
        c.set_text_props(ha="left")
        txt = c.get_text().get_text()
        if len(txt) > 26:
            c.get_text().set_text(txt.replace("_", "_\u200b"))

    plt.title("Final Ranking (WR%)")
    plt.savefig(out_dir / "ranking.png", dpi=160, bbox_inches="tight")
    plt.close()

# ---------- CLI ----------
def parse_args():
    ap = argparse.ArgumentParser(description="Summarize tournament: merge hosts, H2H, WR per round, ranking.")
    ap.add_argument("--roots", nargs="+", required=True,
                    help="Katalogi z wynikami (każdy zawiera *_vs_*.csv i/lub rounds/round_*.csv)")
    ap.add_argument("--out", default="tournament_summary_out", help="Wyjściowy katalog na raporty")
    return ap.parse_args()

def main():
    args = parse_args()
    roots = [Path(p).resolve() for p in args.roots]
    out_dir = Path(args.out).resolve()
    plots_dir = out_dir / "plots"
    plots_dir.mkdir(parents=True, exist_ok=True)

    # 1) wczytaj dane
    pair_df  = load_pair_csvs(roots)
    rounds_df = load_round_csvs(roots)

    # 2) normalizacja nazw botów
    pair_df  = normalize_pairs(pair_df)
    rounds_df = normalize_rounds(rounds_df)

    # 3) ranking i H2H z par
    overall_df = compute_overall_from_pairs(pair_df)
    names, h2h = compute_h2h_from_pairs(pair_df)

    if names:
        # CSV + heatmapa
        # Dodatkowo zapisz h2h csv w formie macierzy z nazwami
        M_rows = []
        for a in names:
            row = {"bot": a}
            for b in names:
                row[b] = (0.5 if a == b else h2h.get((a,b), np.nan))
            M_rows.append(row)
        h2h_df = pd.DataFrame(M_rows).set_index("bot")
        out_dir.mkdir(parents=True, exist_ok=True)
        h2h_df.to_csv(out_dir / "head_to_head.csv")
        plot_h2h(plots_dir, names, h2h)

    inter_map = pd.DataFrame()

    # 4) interleaving rund i wykres WR per round z plików rund
    if not rounds_df.empty:
        host_order = [p.name for p in roots]  # kolejność przeplotu wg kolejności w argumencie
        inter_map = build_interleave_mapping(rounds_df, host_order)
        if not inter_map.empty:
            inter_map.to_csv(out_dir / "round_index_mapping.csv", index=False)
            plot_wr_per_round_from_rounds(plots_dir, rounds_df, inter_map)

    # 5) ranking tabela (CSV + PNG)
    if not rounds_df.empty and not pair_df.empty and not inter_map.empty:
        overall_eq_pairs = equalize_rounds_to_common_games(rounds_df, inter_map)
        if not overall_eq_pairs.empty:
            overall_df = overall_eq_pairs  # <-- ranking z przyciętych par

    if overall_df.empty and not rounds_df.empty:
        # fallback jak wcześniej...
        tmp = rounds_df.groupby("bot", as_index=False).agg(
            wins=("wins","sum"), draws=("draws","sum"), games=("games","sum"))
        tmp["losses"] = tmp["games"] - tmp["wins"] - tmp["draws"]
        tmp["eff_wr"] = (tmp["wins"] + 0.5*tmp["draws"]) / tmp["games"].replace(0, np.nan)
        tmp["eff_wr_pct"] = 100.0 * tmp["eff_wr"]
        overall_df = tmp.sort_values(["eff_wr","games"], ascending=[False, False]).reset_index(drop=True)

    save_ranking_csv_and_png(out_dir, overall_df)

    # 6) krótkie podsumowanie do stdout
    if not overall_df.empty:
        print("\n=== Final Overall (effective WR) ===")
        print(overall_df[["bot","games","wins","draws","losses","eff_wr_pct"]].to_string(index=False))
    else:
        print("Brak danych do zrobienia rankingu.")

    print(f"\nSaved into: {out_dir}")

if __name__ == "__main__":
    main()
