# COG 2026 tournament environment

This environment was prepared from `TournamentRunner-main-final-20260818-082653.tar.gz`.
It contains the final tournament configuration, scripts, submitted bot sources,
Q tables, and the Linux x86-64 GameRunner. Previous results, logs, debug symbols,
and model weights are excluded.

## Required model weights

Obtain the original model weights separately and place them at:

- `cs_agents/DeepSetsBotSubmission/DeepSetsValueNetwork.onnx`
- `cs_agents/patron-zero/model/model.pt`
- `py_agents/Nangert_submission_v6/policy_weights.pt`

All three files are required to reproduce the behavior of all eight bots.
The DeepSets bots can silently use a different evaluator without their model.

## Run

Use Docker with Docker Compose v2. The container targets `linux/amd64` and
allocates 8 CPUs and up to 24 GB of RAM. Other architectures need emulation.
The first build downloads images and dependencies. Matches run with networking
disabled.

Review `config.yaml`. The final configuration schedules 39 rounds, 20 games per
pair per round, and 21,840 games across eight bots. Keep the six patrons unchanged.

```bash
mkdir -p results results-pilot
chmod 0777 results results-pilot
docker compose up --build
```

A restarted run resumes completed matches from `results/`. Start with an empty
results directory after changing the bot list, patron list, or match settings.

## Summary

```bash
docker compose run --rm --no-deps tour python summarize_tournament.py
```

Rankings and summaries are written to `results/`; plots are written to
`results/plots/`. Check that `results/completion_report.json` contains
`"complete": true` before treating the ranking as final.

This environment preserves the setup, but dependency downloads and time-limited,
parallel bot searches mean that identical rankings are not guaranteed.
