# run_tournament.py
import argparse, csv, hashlib, importlib, itertools, json, os, re, socket, sys, time
from dataclasses import dataclass
from pathlib import Path
from subprocess import run, PIPE, CalledProcessError
from typing import List, Optional, Dict, Any, Tuple

from scripts_of_tribute.game import Game

EXPECTED_PATRONS = (
    "PELIN",
    "DUKE_OF_CROWS",
    "ANSEI",
    "RAJHIN",
    "ORGNUM",
    "SAINT_ALESSIA",
)

@dataclass
class Bot:
    id: str
    kind: str                 # "python" | "native"
    cls_path: Optional[str]   # for python, e.g. "py_agents.Bots.RandomBot.RandomBot"
    name: Optional[str]       # python bot_name (and grpc:NAME)
    native_name: Optional[str]# for native C# DLL bot

def load_config(path: str) -> dict:
    import yaml
    return yaml.safe_load(Path(path).read_text(encoding="utf-8"))

def load_configured_patrons(cfg: dict) -> List[str]:
    raw_patrons = cfg.get("patrons")
    if not isinstance(raw_patrons, list) or not all(
        isinstance(patron, str) for patron in raw_patrons
    ):
        raise ValueError("config.yaml must define patrons as a list of names.")

    patrons = tuple(patron.strip().upper() for patron in raw_patrons)
    if patrons != EXPECTED_PATRONS:
        raise ValueError(
            "Tournament patrons must be exactly: "
            + ", ".join(EXPECTED_PATRONS)
        )
    return list(patrons)

def seed_for(*parts: str) -> int:
    s = "|".join(parts)
    h = hashlib.blake2b(s.encode(), digest_size=8).digest()
    return int.from_bytes(h, "big", signed=False)

def name_for(entry: Bot) -> str:
    if entry.kind == "python":
        return f"grpc:{entry.name}"
    if entry.kind == "native":
        return entry.native_name
    raise ValueError("unknown kind")

STDOUT_RE = {
    "total_ms": re.compile(r"Total time taken:\s*([0-9]+(?:\.[0-9]+)?)ms"),
    "avg_ms": re.compile(r"Average time per game:\s*([0-9]+(?:\.[0-9]+)?)ms"),
    "draws":    re.compile(r"Final amount of draws:\s*([0-9]+)/([0-9]+)"),
    "p1":       re.compile(r"Final amount of P1 wins:\s*([0-9]+)/([0-9]+)"),
    "p2":       re.compile(r"Final amount of P2 wins:\s*([0-9]+)/([0-9]+)"),
    "other":    re.compile(r"Ends due to other factors:\s*([0-9]+)/([0-9]+)"),
}

def parse_stdout(stdout: str) -> Dict[str, Any]:
    def pick(key):
        m = STDOUT_RE[key].search(stdout)
        return (int(m.group(1)), int(m.group(2))) if m else (0,0)
    total_ms = int(STDOUT_RE["total_ms"].search(stdout).group(1)) if STDOUT_RE["total_ms"].search(stdout) else None
    avg_ms   = float(STDOUT_RE["avg_ms"].search(stdout).group(1))  if STDOUT_RE["avg_ms"].search(stdout) else None
    d, n = pick("draws")
    p1, _ = pick("p1")
    p2, _ = pick("p2")
    other, _ = pick("other")
    return {
        "games": n, "draws": d, "p1_wins": p1, "p2_wins": p2,
        "other_factors": other, "total_ms": total_ms, "avg_ms": avg_ms
    }

def run_gamerunner_capture(exe_path: Path, left: str, right: str,
                            runs: int, threads: int,
                            log_level: str, log_destination: str,
                            seed: int | None, timeout: int,
                            process_timeout: int,
                            patrons: List[str]) -> tuple[str, str]:
    exe_path = exe_path.resolve()
    args = [str(exe_path), left, right, "-n", str(runs), "-t", str(threads), "-l", log_level, "-to", str(timeout)]
    args += ["--patrons", ",".join(patrons)]
    if log_destination:
        args += ["-d", log_destination]
    if seed is not None:
        args += ["-s", str(seed)]

    r = run(
        args,
        check=True,
        stdout=PIPE,
        stderr=PIPE,
        text=True,
        cwd=str(exe_path.parent),
        timeout=process_timeout,
    )
    return r.stdout, r.stderr

def wait_for_bot_servers(ports: List[int], processes: list, timeout: int = 30):
    pending = set(ports)
    deadline = time.monotonic() + timeout
    while pending:
        failed = [process.name for process in processes if not process.is_alive()]
        if failed:
            raise RuntimeError(f"Python bot server exited before becoming ready: {failed}")
        for port in list(pending):
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                    pending.remove(port)
            except OSError:
                pass
        if pending and time.monotonic() >= deadline:
            raise TimeoutError(f"Python bot servers did not become ready on ports: {sorted(pending)}")
        if pending:
            time.sleep(0.1)

def ensure_runner_has_bots_dir(runner_path: Path):
    bots_dir = runner_path.parent / "Bots"
    bots_dir.mkdir(parents=True, exist_ok=True)
    return bots_dir

# ---------- CSV helpers ----------

def ensure_csv_with_header(path: Path, fieldnames: List[str]):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        with path.open(newline="", encoding="utf-8") as file:
            header = next(csv.reader(file), [])
        if header != fieldnames:
            raise RuntimeError(
                f"Result schema mismatch in {path}; archive or remove stale results."
            )
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=fieldnames).writeheader()

def append_csv_row(path: Path, fieldnames: List[str], row: Dict[str, Any]):
    with path.open("a", newline="", encoding="utf-8") as f:
        cw = csv.DictWriter(f, fieldnames=fieldnames)
        cw.writerow(row)
        f.flush()

def load_completed_side(
    path: Path,
    round_idx: int,
    side: str,
    expected_runs: int,
    expected_patrons: str,
) -> Optional[Dict[str, int]]:
    if not path.exists():
        return None
    with path.open(newline="", encoding="utf-8") as file:
        matches = [
            row for row in csv.DictReader(file)
            if int(row["round_idx"]) == round_idx and row["side"] == side
        ]
    if len(matches) > 1:
        raise RuntimeError(
            f"Duplicate result rows for round {round_idx}, side {side} in {path}."
        )
    if not matches:
        return None
    row = matches[0]
    if int(row["runs"]) != expected_runs or int(row["games"]) != expected_runs:
        raise RuntimeError(
            f"Incomplete existing result for round {round_idx}, side {side} in {path}."
        )
    if row["patrons"] != expected_patrons:
        raise RuntimeError(
            f"Patron mismatch in existing result for round {round_idx}, "
            f"side {side} in {path}."
        )
    return {
        "a_wins": int(row["mapped_a_wins"]),
        "b_wins": int(row["mapped_b_wins"]),
        "draws": int(row["draws"]),
        "games": int(row["games"]),
        "other_factors": int(row.get("other_factors") or 0),
    }


# ---------- One match (one direction) ----------

def play_one_side(
    A: Bot, B: Bot, *,  # A left, B right
    runs: int,
    threads: int,
    timeout: int,
    process_timeout: int,
    log_level: str,
    log_destination: str,
    runner_path: Path,
    round_idx: int,
    results_dir: Path,
    patrons: List[str],
) -> Dict[str, Any]:
    pair_id = f"{A.id}_vs_{B.id}"
    logs_dir = results_dir / "logs" / pair_id
    logs_dir.mkdir(parents=True, exist_ok=True)
    pair_log    = logs_dir / f"{pair_id}.txt"
    pair_errlog = logs_dir / f"{pair_id}.err.txt"

    game = Game()
    def load_py_bot(cls_path: str, name: str):
        mod_name, cls_name = cls_path.rsplit(".", 1)
        mod = importlib.import_module(mod_name)
        cls = getattr(mod, cls_name)
        return cls(bot_name=name)
    a_py = load_py_bot(A.cls_path, A.name) if A.kind == "python" else None
    b_py = load_py_bot(B.cls_path, B.name) if B.kind == "python" else None
    if a_py: game.register_bot(a_py)
    if b_py: game.register_bot(b_py)

    try:
        if a_py or b_py:
            base_client_port = 50000
            base_server_port = 49000
            game.processes = game._run_bot_instances(
                a_py, b_py,
                num_threads=threads,
                base_client_port=base_client_port,
                base_server_port=base_server_port,
            )
            ports = []
            for i in range(threads):
                if a_py:
                    ports.append(base_client_port + i)
                if b_py:
                    ports.append(base_client_port + threads + i)
            wait_for_bot_servers(ports, game.processes)

        patron_spec = ",".join(patrons)
        seed = seed_for("round", str(round_idx), A.id, B.id, patron_spec)
        stdout, stderr = run_gamerunner_capture(
            exe_path=runner_path,
            left=name_for(A), right=name_for(B),
            runs=runs, threads=threads,
            log_level=log_level, log_destination=log_destination,
            seed=seed, timeout=timeout,
            process_timeout=process_timeout,
            patrons=patrons,
        )

        with pair_log.open("a", encoding="utf-8") as flog:
            flog.write(
                f"\n===== {pair_id} | round {round_idx} | LEFT={A.id} "
                f"RIGHT={B.id} | runs={runs} | seed={seed} | "
                f"patrons={patron_spec} =====\n"
            )
            flog.write(stdout)
        if stderr:
            with pair_errlog.open("a", encoding="utf-8") as ferr:
                ferr.write(
                    f"\n===== {pair_id} | round {round_idx} | LEFT={A.id} "
                    f"RIGHT={B.id} | runs={runs} | seed={seed} | "
                    f"patrons={patron_spec} =====\n"
                )
                ferr.write(stderr)

        parsed = parse_stdout(stdout)
        if parsed["games"] != runs:
            raise RuntimeError(
                f"GameRunner reported {parsed['games']} of {runs} requested games "
                f"for {A.id} vs {B.id}."
            )
        return {"seed": seed, **parsed}
    finally:
        if a_py or b_py:
            game._cleanup_processes()

def play_pair_one_round(
    A: Bot, B: Bot,
    *, runs_per_round: int, threads: int, timeout: int, process_timeout: int,
    log_level: str, log_destination: str,
    runner_path: Path, round_idx: int,
    pair_csv: Path,
    patrons: List[str],
) -> Dict[str, Any]:
    # balance sides inside the round: split K into ceil/floor
    left_runs = runs_per_round // 2
    right_runs = runs_per_round - left_runs

    fields = ["pair_id","bot_a","bot_b","round_idx","side","patrons","runs","seed","left","right",
              "p1_wins","p2_wins","draws","other_factors",
              "mapped_a_wins","mapped_b_wins","games","avg_ms"]
    ensure_csv_with_header(pair_csv, fields)
    patron_spec = ",".join(patrons)

    stats = {"a_wins": 0, "b_wins": 0, "draws": 0, "games": 0, "other_factors": 0}
    def add_stats(side_stats: Dict[str, int]):
        for key in stats:
            stats[key] += side_stats[key]

    if left_runs > 0:
        completed = load_completed_side(
            pair_csv, round_idx, "LEFT_A", left_runs, patron_spec
        )
        if completed is not None:
            add_stats(completed)
        else:
            res = play_one_side(
                A, B, runs=left_runs, threads=threads, timeout=timeout, process_timeout=process_timeout,
                log_level=log_level, log_destination=log_destination,
                runner_path=runner_path, round_idx=round_idx, results_dir=pair_csv.parent,
                patrons=patrons,
            )
            side_stats = {
                "a_wins": res["p1_wins"],
                "b_wins": res["p2_wins"],
                "draws": res["draws"],
                "games": res["games"],
                "other_factors": res["other_factors"],
            }
            add_stats(side_stats)
            append_csv_row(pair_csv, fields, {
                "pair_id": f"{A.id}_vs_{B.id}",
                "bot_a": A.id, "bot_b": B.id,
                "round_idx": round_idx, "side": "LEFT_A",
                "patrons": patron_spec,
                "runs": left_runs, "seed": res["seed"],
                "left": name_for(A), "right": name_for(B),
                "p1_wins": res["p1_wins"], "p2_wins": res["p2_wins"], "draws": res["draws"],
                "other_factors": res["other_factors"],
                "mapped_a_wins": side_stats["a_wins"], "mapped_b_wins": side_stats["b_wins"],
                "games": res["games"], "avg_ms": res.get("avg_ms"),
            })

    if right_runs > 0:
        completed = load_completed_side(
            pair_csv, round_idx, "LEFT_B", right_runs, patron_spec
        )
        if completed is not None:
            add_stats(completed)
        else:
            res = play_one_side(
                B, A, runs=right_runs, threads=threads, timeout=timeout, process_timeout=process_timeout,
                log_level=log_level, log_destination=log_destination,
                runner_path=runner_path, round_idx=round_idx, results_dir=pair_csv.parent,
                patrons=patrons,
            )
            side_stats = {
                "a_wins": res["p2_wins"],
                "b_wins": res["p1_wins"],
                "draws": res["draws"],
                "games": res["games"],
                "other_factors": res["other_factors"],
            }
            add_stats(side_stats)
            append_csv_row(pair_csv, fields, {
                "pair_id": f"{A.id}_vs_{B.id}",
                "bot_a": A.id, "bot_b": B.id,
                "round_idx": round_idx, "side": "LEFT_B",
                "patrons": patron_spec,
                "runs": right_runs, "seed": res["seed"],
                "left": name_for(B), "right": name_for(A),
                "p1_wins": res["p1_wins"], "p2_wins": res["p2_wins"], "draws": res["draws"],
                "other_factors": res["other_factors"],
                "mapped_a_wins": side_stats["a_wins"], "mapped_b_wins": side_stats["b_wins"],
                "games": res["games"], "avg_ms": res.get("avg_ms"),
            })

    return stats

# ---------- Main tournament with rounds ----------

def run_tournament_with_rounds(
    bots: List[Bot],
    cfg: dict,
    runner_path: Path,
    results_dir: Path,
    selected_pairs: Optional[set[frozenset[str]]] = None,
):
    rounds = int(cfg.get("rounds", 1))
    threads = int(cfg.get("threads_per_match", 1))
    runs_per_round = int(cfg.get("games_per_pair_per_round", cfg.get("chunk_size", 1)))
    timeout = int(cfg["timeout"])
    process_timeout = int(cfg.get("match_process_timeout", 600))
    log_level = cfg.get("log_level", "NONE")
    log_destination = cfg.get("log_destination", "")
    patrons = load_configured_patrons(cfg)
    print(f"Patrons: {', '.join(patrons)}")

    pairs = list(itertools.combinations(bots, 2))
    if selected_pairs is not None:
        pairs = [
            pair for pair in pairs
            if frozenset((pair[0].id, pair[1].id)) in selected_pairs
        ]
    rounds_dir = results_dir / "rounds"
    rounds_dir.mkdir(parents=True, exist_ok=True)
    leaderboard_fields = ["round_idx","bot","games","wins","draws","losses","eff_wr","eff_wr_pct"]

    cum_pair_stats: Dict[Tuple[str,str], Dict[str,int]] = {}

    for r in range(rounds):
        print(f"\n=== Round {r} ===")
        per_bot = {b.id: {"games":0,"wins":0,"draws":0,"losses":0} for b in bots}

        for A, B in pairs:
            pair_id = f"{A.id}_vs_{B.id}"
            pair_csv = results_dir / f"{pair_id}.csv"
            stats = play_pair_one_round(
                A, B,
                runs_per_round=runs_per_round,
                threads=threads, timeout=timeout, process_timeout=process_timeout,
                log_level=log_level, log_destination=log_destination,
                runner_path=runner_path, round_idx=r,
                pair_csv=pair_csv,
                patrons=patrons,
            )

            per_bot[A.id]["wins"]  += stats["a_wins"]
            per_bot[A.id]["draws"] += stats["draws"]
            per_bot[A.id]["games"] += stats["games"]
            per_bot[A.id]["losses"] = per_bot[A.id]["games"] - per_bot[A.id]["wins"] - per_bot[A.id]["draws"]

            per_bot[B.id]["wins"]  += stats["b_wins"]
            per_bot[B.id]["draws"] += stats["draws"]
            per_bot[B.id]["games"] += stats["games"]
            per_bot[B.id]["losses"] = per_bot[B.id]["games"] - per_bot[B.id]["wins"] - per_bot[B.id]["draws"]

            k = (A.id, B.id)
            if k not in cum_pair_stats:
                cum_pair_stats[k] = {"a_wins":0,"b_wins":0,"draws":0,"games":0,"other_factors":0}
            for key in ["a_wins","b_wins","draws","games","other_factors"]:
                cum_pair_stats[k][key] += stats[key]

            print(f"  {A.id} vs {B.id}: +{stats['a_wins']}-{stats['b_wins']}-{stats['draws']} / {stats['games']}")

        lb_path = rounds_dir / f"round_{r}.csv"
        with lb_path.open("w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=leaderboard_fields)
            writer.writeheader()
            for bot_id, s in per_bot.items():
                games = s["games"]
                eff = (s["wins"] + 0.5*s["draws"]) / games if games else 0.0
                writer.writerow({
                    "round_idx": r, "bot": bot_id,
                    "games": games, "wins": s["wins"], "draws": s["draws"], "losses": s["losses"],
                    "eff_wr": eff, "eff_wr_pct": 100.0*eff
                })

    for (aid, bid), st in cum_pair_stats.items():
        summary = {
            "pair_id": f"{aid}_vs_{bid}",
            "A": aid, "B": bid,
            **st,
            "A_effWR": (st["a_wins"] + 0.5*st["draws"]) / st["games"] if st["games"] else 0.0,
            "timestamp": int(time.time())
        }
        (results_dir / f"{aid}_vs_{bid}_summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--only-pairs", nargs="*", default=None, help="Optional: list of pairs in format A:B")
    args = ap.parse_args()

    cfg = load_config(args.config)
    results_dir = Path(cfg.get("results_dir", "results"))
    results_dir.mkdir(parents=True, exist_ok=True)

    runner_path = None
    if cfg.get("use_local_runner", True):
        runner_path = Path(cfg["runner_path"])
        ensure_runner_has_bots_dir(runner_path)

    bots = [Bot(
        id=b["id"],
        kind=b["kind"],
        cls_path=b.get("class"),
        name=b.get("name"),
        native_name=b.get("native_name"),
    ) for b in cfg["bots"]]
    by_id = {b.id: b for b in bots}

    selected_pairs = None
    if args.only_pairs:
        selected_pairs = set()
        for pair in args.only_pairs:
            parts = pair.split(":")
            if len(parts) != 2 or parts[0] == parts[1]:
                raise ValueError(f"Invalid pair '{pair}'. Expected A:B with distinct bot IDs.")
            unknown = [bot_id for bot_id in parts if bot_id not in by_id]
            if unknown:
                raise ValueError(f"Unknown bot IDs in pair '{pair}': {unknown}")
            selected_pairs.add(frozenset(parts))

    run_tournament_with_rounds(
        bots,
        cfg,
        Path(cfg["runner_path"]),
        results_dir,
        selected_pairs,
    )

if __name__ == "__main__":
    main()
    print("~~~~~~~Done~~~~~~~")
