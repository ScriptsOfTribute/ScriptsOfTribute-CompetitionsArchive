import argparse, itertools, json, re, time
from pathlib import Path
from typing import Dict, Tuple, List
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patheffects as path_effects
import yaml

RESULTS_DIR = Path("results")
ROUNDS_DIR  = RESULTS_DIR / "rounds"
PLOTS_DIR   = RESULTS_DIR / "plots"

PAIR_SUMMARY_RE = re.compile(r"(.+)_vs_(.+)_summary\.json$")

# --------- loaders ---------

def load_pair_rounds() -> pd.DataFrame:
    records = []
    seen = set()
    for path in sorted(RESULTS_DIR.glob("*_vs_*.csv")):
        df = pd.read_csv(path)
        required = {
            "pair_id", "round_idx", "side", "runs", "seed", "games",
            "draws", "mapped_a_wins", "mapped_b_wins",
        }
        if not required.issubset(df.columns):
            continue
        for row in df.to_dict(orient="records"):
            key = (row["pair_id"], int(row["round_idx"]), row["side"], int(row["seed"]))
            if key in seen:
                raise RuntimeError(f"Duplicate result row detected: {key}")
            seen.add(key)
            games = int(row["games"])
            if games != int(row["runs"]):
                raise RuntimeError(f"Incomplete result row detected: {key}")
            if "bot_a" in row and "bot_b" in row and pd.notna(row["bot_a"]) and pd.notna(row["bot_b"]):
                bot_a, bot_b = str(row["bot_a"]), str(row["bot_b"])
            else:
                match = re.fullmatch(r"(.+)_vs_(.+)", str(row["pair_id"]))
                if match is None:
                    raise RuntimeError(f"Invalid pair ID: {row['pair_id']}")
                bot_a, bot_b = match.groups()
            draws = int(row["draws"])
            other_factors = int(row.get("other_factors", 0) or 0)
            a_wins = int(row["mapped_a_wins"])
            b_wins = int(row["mapped_b_wins"])
            records.extend([
                {
                    "round_idx": int(row["round_idx"]), "bot": bot_a,
                    "games": games, "wins": a_wins, "draws": draws,
                    "losses": games - a_wins - draws, "other_factors": other_factors,
                },
                {
                    "round_idx": int(row["round_idx"]), "bot": bot_b,
                    "games": games, "wins": b_wins, "draws": draws,
                    "losses": games - b_wins - draws, "other_factors": other_factors,
                },
            ])
    if not records:
        return pd.DataFrame()
    return pd.DataFrame(records).groupby(["round_idx", "bot"], as_index=False).agg(
        games=("games", "sum"),
        wins=("wins", "sum"),
        draws=("draws", "sum"),
        losses=("losses", "sum"),
        other_factors=("other_factors", "sum"),
    )

def load_round_leaderboards() -> pd.DataFrame:
    pair_rounds = load_pair_rounds()
    if not pair_rounds.empty:
        pair_rounds["eff_wr"] = (
            pair_rounds["wins"] + 0.5 * pair_rounds["draws"]
        ) / pair_rounds["games"].replace(0, np.nan)
        pair_rounds["eff_wr_pct"] = 100.0 * pair_rounds["eff_wr"]
        return pair_rounds
    if not ROUNDS_DIR.exists():
        return pd.DataFrame(columns=["round_idx","bot","games","wins","draws","losses","eff_wr","eff_wr_pct"])

    rows = []
    for f in sorted(ROUNDS_DIR.glob("round_*.csv")):
        try:
            df = pd.read_csv(f)
        except Exception:
            continue
        need = {"round_idx","bot","games","wins","draws","losses"}
        if not need.issubset(df.columns):
            continue
        df["round_idx"] = df["round_idx"].astype(int)
        rows.append(df)

    if not rows:
        return pd.DataFrame(columns=["round_idx","bot","games","wins","draws","losses","eff_wr","eff_wr_pct"])

    df = pd.concat(rows, ignore_index=True)
    if "eff_wr" not in df.columns:
        df["eff_wr"] = (df["wins"] + 0.5*df["draws"]) / df["games"].replace(0, np.nan)
    if "eff_wr_pct" not in df.columns:
        df["eff_wr_pct"] = 100.0 * df["eff_wr"]
    return df

def load_pair_summaries() -> List[Dict]:
    from_csv = []
    for path in sorted(RESULTS_DIR.glob("*_vs_*.csv")):
        df = pd.read_csv(path)
        required = {
            "bot_a", "bot_b", "mapped_a_wins", "mapped_b_wins",
            "draws", "games",
        }
        if not required.issubset(df.columns) or df.empty:
            continue
        bot_a = str(df.iloc[0]["bot_a"])
        bot_b = str(df.iloc[0]["bot_b"])
        games = int(df["games"].sum())
        draws = int(df["draws"].sum())
        a_wins = int(df["mapped_a_wins"].sum())
        b_wins = int(df["mapped_b_wins"].sum())
        from_csv.append({
            "pair_id": f"{bot_a}_vs_{bot_b}",
            "A": bot_a,
            "B": bot_b,
            "a_wins": a_wins,
            "b_wins": b_wins,
            "draws": draws,
            "games": games,
            "other_factors": int(df.get("other_factors", pd.Series(dtype=int)).sum()),
            "A_effWR": (a_wins + 0.5 * draws) / games if games else 0.0,
        })
    if from_csv:
        return from_csv

    out = []
    for p in RESULTS_DIR.glob("*_summary.json"):
        m = PAIR_SUMMARY_RE.search(p.name)
        if not m:
            continue
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            out.append(d)
        except Exception:
            pass
    return out

def build_completion_report(config_path: Path) -> Dict:
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    bot_ids = [bot["id"] for bot in config["bots"]]
    rounds = int(config.get("rounds", 1))
    games_per_round = int(config.get("games_per_pair_per_round", config.get("chunk_size", 1)))
    expected_sides = []
    side_runs = {
        "LEFT_A": games_per_round // 2,
        "LEFT_B": games_per_round - games_per_round // 2,
    }
    for bot_a, bot_b in itertools.combinations(bot_ids, 2):
        for round_idx in range(rounds):
            for side, runs in side_runs.items():
                if runs > 0:
                    expected_sides.append((frozenset((bot_a, bot_b)), round_idx, side, runs))

    actual = {}
    duplicates = []
    incomplete = []
    actual_games = 0
    other_factors = 0
    for path in sorted(RESULTS_DIR.glob("*_vs_*.csv")):
        df = pd.read_csv(path)
        for row in df.to_dict(orient="records"):
            pair = frozenset((str(row["bot_a"]), str(row["bot_b"])))
            key = (pair, int(row["round_idx"]), str(row["side"]))
            if key in actual:
                duplicates.append(f"{sorted(pair)} round={key[1]} side={key[2]}")
            actual[key] = int(row["games"])
            actual_games += int(row["games"])
            other_factors += int(row.get("other_factors", 0) or 0)
            if int(row["runs"]) != int(row["games"]):
                incomplete.append(f"{path.name} round={key[1]} side={key[2]}")

    missing = []
    for pair, round_idx, side, runs in expected_sides:
        key = (pair, round_idx, side)
        if actual.get(key) != runs:
            missing.append(f"{sorted(pair)} round={round_idx} side={side}")

    expected_games = len(list(itertools.combinations(bot_ids, 2))) * rounds * games_per_round
    report = {
        "complete": not missing and not duplicates and not incomplete and actual_games == expected_games,
        "expected_games": expected_games,
        "actual_games": actual_games,
        "other_factors": other_factors,
        "missing_sides": missing,
        "duplicate_sides": duplicates,
        "incomplete_rows": incomplete,
    }
    (RESULTS_DIR / "completion_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return report

# --------- computations ---------

def overall_from_rounds(rounds_df: pd.DataFrame) -> pd.DataFrame:
    if rounds_df.empty:
        return pd.DataFrame(columns=["bot","games","wins","draws","losses","eff_wr","eff_wr_pct"])

    g = rounds_df.groupby("bot", as_index=False).agg(
        games=("games","sum"),
        wins=("wins","sum"),
        draws=("draws","sum"),
        losses=("losses","sum"),
    )
    g["eff_wr"] = (g["wins"] + 0.5*g["draws"]) / g["games"].replace(0, np.nan)
    g["eff_wr_pct"] = 100.0 * g["eff_wr"]
    g = g.sort_values(["eff_wr","games"], ascending=[False, False]).reset_index(drop=True)
    return g

def compute_h2h_from_summaries(summaries: List[Dict]) -> Tuple[List[str], Dict[Tuple[str,str], Dict]]:
    names = sorted({d["A"] for d in summaries} | {d["B"] for d in summaries})
    h2h: Dict[Tuple[str,str], Dict] = {}
    for d in summaries:
        A, B = d["A"], d["B"]
        a_w, b_w, draws, n = d["a_wins"], d["b_wins"], d["draws"], d["games"]
        k = (A, B)
        h2h[k] = {
            "A": A, "B": B,
            "a_wins": a_w, "b_wins": b_w, "draws": draws, "games": n,
            "A_effWR": (a_w + 0.5*draws) / n if n else 0.0
        }
        k_rev = (B, A)
        h2h[k_rev] = {
            "A": B, "B": A,
            "a_wins": b_w, "b_wins": a_w, "draws": draws, "games": n,
            "A_effWR": (b_w + 0.5*draws) / n if n else 0.0
        }
    return names, h2h

# --------- plots ---------

def plot_h2h_matrix(names: List[str], h2h: Dict[Tuple[str,str], Dict]):
    M = np.full((len(names), len(names)), np.nan)
    for i, a in enumerate(names):
        for j, b in enumerate(names):
            if i != j:
                wr = h2h.get((a, b), {}).get("A_effWR", np.nan)
                M[i, j] = 100.0 * wr if not np.isnan(wr) else np.nan

    plt.figure(figsize=(0.7*len(names)+2, 0.7*len(names)+2))
    im = plt.imshow(M, vmin=0, vmax=100, interpolation="nearest", aspect="equal", cmap="RdYlGn")
    cbar = plt.colorbar(im, fraction=0.046, pad=0.04)
    cbar.set_label("Eff. WR (%) — row vs col")
    plt.xticks(range(len(names)), names, rotation=90)
    plt.yticks(range(len(names)), names)
    plt.title("Head-to-Head Win Rate (%)")

    for i in range(len(names)):
        for j in range(len(names)):
            if i == j:
                continue
            val = M[i, j]
            if not np.isnan(val):
                txt = plt.text(j, i, f"{val:.1f}%", ha="center", va="center", fontsize=8, color="white")
                txt.set_path_effects([
                    path_effects.Stroke(linewidth=1.2, foreground='black'),
                    path_effects.Normal()
                ])

    plt.tight_layout()
    out = PLOTS_DIR / "h2h_matrix.png"
    plt.savefig(out, dpi=160)
    plt.close()

def plot_wr_per_round(rounds_df: pd.DataFrame):
    if rounds_df.empty:
        print("No files results/rounds/round_*.csv — skip WR-per-round plot.")
        return

    df = rounds_df.copy()
    df["round_idx"] = df["round_idx"].astype(int)
    df = df.sort_values(["bot","round_idx"])

    df["cum_wins"]   = df.groupby("bot")["wins"].cumsum()
    df["cum_draws"]  = df.groupby("bot")["draws"].cumsum()
    df["cum_games"]  = df.groupby("bot")["games"].cumsum()
    df["cum_eff_wr"] = (df["cum_wins"] + 0.5*df["cum_draws"]) / df["cum_games"].replace(0, np.nan)
    df["cum_eff_wr_pct"] = 100.0 * df["cum_eff_wr"]

    piv = df.pivot_table(index="round_idx", columns="bot", values="cum_eff_wr_pct", aggfunc="last")
    piv = piv.sort_index()

    last = piv.tail(1).T.squeeze()
    piv = piv.loc[:, last.sort_values(ascending=False).index]

    (RESULTS_DIR / "wr_per_round_cumulative.csv").write_text(piv.to_csv(index=True), encoding="utf-8")

    plt.figure(figsize=(max(10, 1.2*len(piv.columns)), 6))
    for bot in piv.columns:
        plt.plot(piv.index.astype(int), piv[bot], marker="o", label=bot)
    plt.xlabel("round_idx")
    plt.ylabel("Cumulative effective WR (%)")
    plt.title("Cumulative WR (%) by bot across rounds")
    plt.ylim(0, 100)
    plt.xticks(piv.index.astype(int))
    plt.grid(True, alpha=0.3)
    ncol = 1 if len(piv.columns) <= 10 else 2
    plt.legend(loc="center left", bbox_to_anchor=(1.0, 0.5), ncol=ncol, frameon=False)
    plt.tight_layout()
    out = PLOTS_DIR / "wr_per_round.png"
    plt.savefig(out, dpi=160, bbox_inches="tight")
    plt.close()

# --------- main ---------

def main(config_path: Path, results_dir: Path):
    global RESULTS_DIR, ROUNDS_DIR, PLOTS_DIR
    RESULTS_DIR = results_dir
    ROUNDS_DIR = RESULTS_DIR / "rounds"
    PLOTS_DIR = RESULTS_DIR / "plots"
    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    completion = build_completion_report(config_path)
    rounds_df = load_round_leaderboards()
    overall_df = overall_from_rounds(rounds_df)
    if not overall_df.empty:
        overall_df.to_csv(RESULTS_DIR / "overall_ranking.csv", index=False)

    summaries = load_pair_summaries()
    if summaries:
        names, h2h = compute_h2h_from_summaries(summaries)
        M_rows = []
        for a in names:
            row = {"bot": a}
            for b in names:
                row[b] = 0.5 if a == b else h2h.get((a,b), {}).get("A_effWR", np.nan)
            M_rows.append(row)
        h2h_df = pd.DataFrame(M_rows).set_index("bot")
        h2h_df.to_csv(RESULTS_DIR / "head_to_head.csv")
        plot_h2h_matrix(names, h2h)

        tournament_json = {
            "bots": sorted(set(rounds_df["bot"])) if not rounds_df.empty else names,
            "ranking": overall_df.to_dict(orient="records"),
            "pairs": summaries,
            "generated_at": int(time.time())
        }
        (RESULTS_DIR / "tournament_summary.json").write_text(
            json.dumps(tournament_json, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

    plot_wr_per_round(rounds_df)

    if not overall_df.empty:
        print("\n=== Overall ranking (by effective WR; summed across rounds) ===")
        print(overall_df.to_string(index=False))
    else:
        print("No round CSVs found in results/rounds/ — overall ranking not generated.")

    print("\nFiles saved in:", RESULTS_DIR.resolve())
    print(
        f"  - completion_report.json "
        f"({'COMPLETE' if completion['complete'] else 'INCOMPLETE'}: "
        f"{completion['actual_games']}/{completion['expected_games']} games, "
        f"other factors={completion['other_factors']})"
    )
    if not overall_df.empty:
        print("  - overall_ranking.csv")
        print("  - wr_per_round_cumulative.csv")
        print("  - plots/wr_per_round.png")
    if summaries:
        print("  - head_to_head.csv")
        print("  - plots/h2h_matrix.png")
        print("  - tournament_summary.json")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--results-dir", default="results")
    args = parser.parse_args()
    main(Path(args.config), Path(args.results_dir))